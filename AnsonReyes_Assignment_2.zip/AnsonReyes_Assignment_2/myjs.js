var salesman =
{
    Salesman_info:
    {
        fname:"Pasta",
        lname:"Linguini",
        purpose:"I hope I can help you make a purchase today."
    },
    Vehicles:
    {
        KIA:
        {
            Soul:
            {
                year: 2008,
                cost: 100000
            },
            Sportage:
            {
                year: 2012,
                cost: 180000
            },
            Rio:
            {
                year: 2010,
                cost: 150000
            }
        },
        Nissan:
        {
            Sentra:
            {
                year: 2001,
                cost: 50000
            },
            Pathfire:
            {
                year: 2010,
                cost: 90000
            },
            Versa:
            {
                year: 2015,
                cost: 100000
            }
        },
        Toyota:
        {
            Hilux:
            {
                year: 2005,
                cost: 120000
            },
            Corolla:
            {
                year: 2019,
                cost: 150000
            },
            Prado:
            {
                year: 2014,
                cost: 140000
            }
        }
    },
    greet:function()
    {
        console.log("Good day my name is " 
        + this.Salesman_info.fname + " " + this.Salesman_info.lname + ", " + this.Salesman_info.purpose);
    },
    listAllModels:function()
    {
        for(let x in this.Vehicles)
        {
            console.log(x);
        }
    },
    listModelsByMake:function()
    {
        for(let x in this.Vehicles)
        {
            console.log(x);
            let make = this.Vehicles[x];
            for(let y in make)
            {
                console.log("   " + y);
            }
        }
    },
    listAllVehicleDetails:function()
    {
        for(let x in this.Vehicles)
        {
            console.log(x);
            let make = this.Vehicles[x];
            for(let y in make)
            {
                console.log("   " + y);
                let details = make[y];
                for(let z in details)
                {
                    console.log("      " + z+ "  " + details[z]);
                }
            }
        }
    },
    sellMeA:function(brand,make)
    {
        if(brand === "KIA")
        {
            switch(make){
            case "Soul":
                console.log("KIA " + "Soul " + this.Vehicles.KIA.Soul.year + " " + "$" + this.Vehicles.KIA.Soul.cost);
                break;
            case "Sportage":
                console.log("KIA " + "Sportage " + this.Vehicles.KIA.Sportage.year + " " + "$" + this.Vehicles.KIA.Sportage.cost);
                break;
            case "Rio":
                console.log("KIA " + "Rio " + this.Vehicles.KIA.Rio.year + " " + "$" + this.Vehicles.KIA.Rio.cost);
                break;
            default:
                console.log("Please enter the correct make");
            }
        }
        else if(brand === "Nissan")
        {
            switch(make){
            case "Sentra":
                console.log("Nissan " + "Sentra " + this.Vehicles.Nissan.Sentra.year + " " + "$" + this.Vehicles.Nissan.Sentra.cost);
                break;
            case "Pathfire":
                console.log("Nissan " + "Pathfire " + this.Vehicles.Nissan.Pathfire.year + " " + "$" + this.Vehicles.Nissan.Pathfire.cost);
                break;
            case "Versa":
                console.log("Nissan " + "Versa " + this.Vehicles.Nissan.Versa.year + " " + "$" + this.Vehicles.Nissan.Versa.cost);
                break;
            default:
                console.log("Please enter the correct make");
            }
        }
        else if(brand === "Toyota")
        {
            switch(make){
            case "Hilux":
                console.log("Toyota " + "Hilux " + this.Vehicles.Toyota.Hilux.year + " " + "$" + this.Vehicles.Toyota.Hilux.cost);
                break;
            case "Corolla":
                console.log("Toyota " + "Corolla " + this.Vehicles.Toyota.Corolla.year + " " + "$" + this.Vehicles.Toyota.Corolla.cost);
                break;
            case "Prado":
                console.log("Toyota " + "Prado " + this.Vehicles.Toyota.Prado.year + " " + "$" + this.Vehicles.Toyota.Prado.cost);
                break;
            default:
                console.log("Please enter the correct make");
            }
        }
        else
        {
            console.log("Please enter the correct model");
        }
    }
}